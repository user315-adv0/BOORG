BOORG — Bookmark Organizer and Metadata Scanner (Unpacked Build)

How to install (Chrome):
1) Download and unzip this archive
2) Open chrome://extensions
3) Enable "Developer mode" (top-right)
4) Click "Load unpacked" and select the extracted folder

What it does:
- Scan bookmarks and fetch metadata (title/description)
- Remove invalid links
- Sort valid links under Bookmarks Bar/SORTED
- Optional: split into folders or keep flat
- Export to CSV (Export button)

Buttons:
- Scan: fetches metadata for all bookmarks
- Sort: removes invalid links and organizes valid ones under SORTED
- Integrate: re-integrates current records to SORTED (use after tweaks)
- Export: opens CSV export page / downloads CSV

Settings (gear icon):
- Simplify deep links to domain root
- Remove duplicates
- Split into folders (SORTED)
- Flat mode (no subfolders)

Permissions:
- bookmarks, storage, downloads, <all_urls>

Note:
- This is an MV3 extension using a service worker
- No external services


